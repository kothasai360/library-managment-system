# Library-Management-System (python)
This repository contains library management system, made while learning Tkinter module (python's GUI toolkit) and the sqlite3 library(built-in database/sql interface).


1. To **RUN** the program just execute **'login_register.py'** {but rest of the files should also be present in the same 		   			  directory}.
2. To login as Admin or Student, click on the desired button on top of the window.
3. Default Admin **username='admin'** and **password='admin'**.
4. But to login as Student, user have to first SignUp to fill his/her credentials then he/she can login into the student window 		through the registered name and password.
